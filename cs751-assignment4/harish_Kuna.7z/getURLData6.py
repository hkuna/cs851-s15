import json
import string
import subprocess
import time

f = open('urlStatusAfterCurlCalls5','r+')
i=5000
for line in f:
	data = json.loads(line)
	link = str(i)
	url = "http://labs.mementoweb.org/timemap/link/"+data['lasturl']
	subprocess.Popen(['wget','--output-document='+link,url])
	i=i+1