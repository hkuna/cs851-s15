import json
import string
import subprocess
import time

f = open('urlStatusAfterCurlCalls6','r+')
i=6000
for line in f:
	data = json.loads(line)
	link = str(i)
	url = "http://labs.mementoweb.org/timemap/link/"+data['lasturl']
	subprocess.Popen(['wget','--output-document='+link,url])
	i=i+1